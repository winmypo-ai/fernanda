# Propuesta Sorpresa - Versión Elegante

Versión con diseño elegante:
- Fondo negro degradado
- Tipografías románticas
- Botón dorado minimalista
- Pantalla completa responsive
- Música al pulsar

Subir a GitHub y activar GitHub Pages para compartir por WhatsApp.
